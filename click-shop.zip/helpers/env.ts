// Environment variables

// API URL
export const API_URL = process.env.API_URL || 'http://localhost:5000';
