import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Profile',
};

const ProfilePage = () => {
  return <div>ProfilePage</div>;
};

export default ProfilePage;
